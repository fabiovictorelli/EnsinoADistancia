chown mailman.mailman lista-addlista lista-addusu  lista-exclui lista-removeusu 
chmod +s lista-addlista lista-addusu  lista-exclui lista-removeusu 
