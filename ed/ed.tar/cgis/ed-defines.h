/*
  seg set 21 10:48:39 /etc/localtime 1998
  fabio@conectiva.com.br

  Define as macros para os programas do sistema Educacao a Distancia
*/

#define ALIASES "/etc/aliases"
#define TAMMAXLISTA 50
#define TMPDIR "/tmp"
/*
  seg set 21 10:48:39 /etc/localtime 1998
  fabio@conectiva.com.br

  Define as macros para os programas do sistema Educacao a Distancia
*/

#define ALIASES "/etc/aliases"
#define TAMMAXLISTA 50
#define TMPDIR "/tmp"
#define TMPSQL ".s.PGSQL."
#define ERRO -1
#define OK 0

#define SENHAMAILMAN "teste"
#define TMPSQL ".s.PGSQL."
#define ERRO -1
#define OK 0

#define SENHAMAILMAN "teste"
